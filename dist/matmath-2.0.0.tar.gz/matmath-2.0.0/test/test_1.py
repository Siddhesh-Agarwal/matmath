import matmath as mm

I3 = mm.Identity(3)
print(I3)